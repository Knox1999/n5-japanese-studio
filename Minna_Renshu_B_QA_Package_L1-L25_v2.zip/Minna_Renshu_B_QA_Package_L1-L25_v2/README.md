# Minna no Nihongo 練習B Q&A Package (Lesson 1-25)

This package is for website deployment.

## Included
- Lesson 1-25
- Original 練習B question pages (2 images per lesson)
- Corresponding answer page from the back of the PDF (1 image per lesson)
- Lesson-wise JSON files

## Folder summary
- `data/index.json`
- `data/lesson-01.json` ... `lesson-25.json`
- `images/questions/lesson-XX/`
- `images/answers/lesson-XX-answers.jpg`

## How to use
1. Load a lesson JSON.
2. Show the two question-page images.
3. When user clicks Show Answer, display `answerKey.image`.

## Note
This package includes answer page images, not fully typed/transcribed per-question answers. That means the correct answers are present and viewable in the deployed site, while preserving the original book formatting.
