
const sel=document.getElementById('lesson');
const content=document.getElementById('content');
for(let i=1;i<=25;i++){let o=document.createElement('option');o.value=i;o.textContent=`Lesson ${i}`;sel.appendChild(o)}
async function loadLesson(n){
  const p=`../data/lesson-${String(n).padStart(2,'0')}.json`;
  const d=await fetch(p).then(r=>r.json());
  content.innerHTML='';
  d.sourceSheets.forEach((s, idx)=>{
    const img=document.createElement('img');
    img.className='sheet';
    img.src=`../images/lesson-${String(n).padStart(2,'0')}/renshu-b-sheet-${idx+1}.jpg`;
    img.alt=`Lesson ${n} Renshu B source`;
    content.appendChild(img);
  });
  if(!d.exercises.length){
    const note=document.createElement('p');
    note.className='note';
    note.textContent=d.verificationNote || 'Question data pending.';
    content.appendChild(note);
    return;
  }
  d.exercises.forEach(ex=>{
    const card=document.createElement('section'); card.className='card';
    card.innerHTML=`<h2>練習B ${ex.exerciseNo}</h2><p>${ex.prompt||''}</p>`;
    ex.items.forEach(q=>{
      const item=document.createElement('div'); item.className='item';
      item.innerHTML=`<strong>${q.id}</strong><p>${q.question||q.cue||''}</p>
      <button>Show answer</button><div class="answer">${q.answer||''}</div>`;
      const b=item.querySelector('button'), a=item.querySelector('.answer');
      b.onclick=()=>{a.style.display=a.style.display==='block'?'none':'block';};
      card.appendChild(item);
    });
    content.appendChild(card);
  });
}
sel.onchange=()=>loadLesson(Number(sel.value));
loadLesson(1);
